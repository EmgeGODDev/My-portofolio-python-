import time
import os

# === SETUP WARNA ===
BLUE = "\033[94m"
CYAN = "\033[96m"
WHITE = "\033[97m"
RESET = "\033[0m"
BOLD = "\033[1m"
GREEN = "\033[92m"

def ketik(teks, delay=0.03):
    """Efek ketik pelan-pelan"""
    for c in teks:
        print(c, end='', flush=True)
        time.sleep(delay)
    print()

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def loading():
    """Animasi loading bar"""
    for i in range(101):
        bar = "#" * (i // 5) + "-" * (20 - i // 5)
        print(f"\r[{bar}] {i}%", end='', flush=True)
        time.sleep(0.015)
    print("\n")

# === MULAI PROGRAM ===
clear()
print("=" * 50)
ketik(">> LOADING PORTOFOLIO SYSTEM...", 0.02)
time.sleep(0.3)
loading()
ketik(f"{GREEN}[ACCESS GRANTED]{RESET}\n", 0.05)

# === LOGO ===
print(BLUE + BOLD)
print(r" __  __ __   __    ____    ___   ____   _____   ___   _____   ___   _      ___   ___  ")
print(r"|  \/  |\ \ / /   |  _ \  / _ \ |  _ \ |_   _| / _ \ |  ___| / _ \ | |    |_ _| / _ \ ")
print(r"| |\/| | \ V /    | |_) || | | || |_) |  | |  | | | || |_   | | | || |     | | | | | |")
print(r"| |  | |  | |     |  __/ | |_| ||  _ <   | |  | |_| ||  _|  | |_| || |___  | | | |_| |")
print(r"|_|  |_|  |_|     |_|     \___/ |_| \_\  |_|   \___/ |_|     \___/ |_____||___| \___/ ")
print(RESET)
print(BLUE + BOLD + "                 MY PORTOFOLIO" + RESET)
print("")
ketik(f"            {WHITE}{BOLD}MUHAMMAD FEBRY SAPUTRA{RESET}", 0.04)
print("-" * 50)

# === DATA PORTOFOLIO ===
data = [
    ("Nama", "Muhammad Febry Saputra"),
    ("Umur", "15 Tahun"),
    ("Pendidikan", "SMP"),
    ("Keahlian", "Frontend Developer"),
    ("Bahasa", "HTML, CSS, JavaScript"),
    ("Email", "emgegodt@gmail.com"),
    ("Perusahaan", "EmgeGOD"),
    ("Lokasi", "Brebes, Jawa Tengah"),
]

for key, value in data:
    ketik(f"{CYAN}{key:<12}: {WHITE}{value}{RESET}", 0.02)

# === FOOTER ===
print("")
print(f"{BLUE}>> Tentang Saya:{RESET}")
ketik("Frontend Dev, Fokus bikin website dengan tampilan simpel, keren dan profesional.", 0.03)
print("")
ketik(f"{BOLD}{BLUE}>> SYSTEM READY. PORTOFOLIO ONLINE.{RESET}", 0.03)