# EmgeGOD Portfolio Terminal

A simple terminal-based personal portfolio built with Python.

The project displays a futuristic portfolio-style interface directly in the terminal, including a loading animation, typing effect, ASCII logo, personal information, and a short introduction.

## Features

- Terminal loading animation
- Typing text effect
- ANSI terminal colors
- ASCII portfolio logo
- Personal portfolio information
- Windows and Linux/macOS terminal clearing support
- No external Python packages required

## Requirements

- Python 3.8 or newer
- A terminal that supports ANSI colors

## Run Locally

Clone the repository:

```bash
git clone https://github.com/YOUR_USERNAME/emgegod-portfolio-terminal.git
cd emgegod-portfolio-terminal
```

Run the program:

```bash
python src/main.py
```

On some systems:

```bash
python3 src/main.py
```

## Project Structure

```text
emgegod-portfolio-terminal/
├── src/
│   └── main.py
├── .gitignore
├── .python-version
├── LICENSE
└── README.md
```

## Technologies

- Python
- ANSI escape codes
- Python standard library (`os`, `time`)

## Author

**Muhammad Febry Saputra**

- Brand: EmgeGOD
- Email: emgegodt@gmail.com
- Focus: Frontend Development

## License

This project is licensed under the MIT License. See [LICENSE](LICENSE) for details.
